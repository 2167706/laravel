<?php

use App\Models\Media;
use App\Models\Actor;
use App\Http\Controllers\FilmController;
use App\Http\Controllers\ActorController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    $films = Media::where('is_movie', true)->get();
    $actors = Actor::all();
    return view('welcome', compact('films', 'actors'));
});

// Films/Series routes
Route::get('/films', [FilmController::class,'index']);
Route::get('/films/{id}', 'FilmController@show');

// Actors routes
Route::get('/actors', [ActorController::class, 'index']);
Route::get('/actors/{id}', 'ActorController@show');

