<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Actor;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class ActorController extends Controller
{
    public function index()
    {
        // Fetch all actors from the database
        $actors = Actor::all();
        
        // Pass the actors to the view
        return view('actors.index', compact('actors'));
    }

    public function show($id)
    {
        try {
            // Find the actor with the given ID
            $actor = Actor::findOrFail($id);
            // Pass the actor to the view
            return view('actors.show', compact('actor'));
        } catch (ModelNotFoundException $e) {
            // If actor not found, return a 404 error
            abort(404);
        }
    }
}
