<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Media;
use App\Models\Actor;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class FilmController extends Controller
{
    public function index()
{
    $films = Media::where('is_movie', true)->get();
    $actors = Actor::all();
    return view('welcome', compact('films', 'actors'));
}

    

    public function show($id)
    {
        try {
            $film = Media::findOrFail($id);
            return view('films.show', compact('film'));
        } catch (ModelNotFoundException $e) {
            return response()->view('errors.404', [], 404);
        }
    }
}
