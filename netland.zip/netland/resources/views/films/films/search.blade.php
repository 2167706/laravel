@extends('layouts.app')

@section('content')
    <h1>Search Films</h1>
    <!-- Add search form here -->
    <form action="{{ route('films.search') }}" method="GET">
        <input type="text" name="query" placeholder="Search...">
        <button type="submit">Search</button>
    </form>
    
    <h2>Search Results</h2>
    <ul>
        @foreach ($films as $film)
            <li>{{ $film->title }}</li>
            <!-- Display other film information here -->
        @endforeach
    </ul>
@endsection
