@extends('layouts.app')

@section('content')
    <h1>List of Films</h1>
    <ul>
        @foreach ($films as $film)
            <li>{{ $film->title }}</li>
            <!-- Display other film information here -->
        @endforeach
    </ul>
@endsection
