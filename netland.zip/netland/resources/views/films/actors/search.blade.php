@extends('layouts.app')

@section('content')
    <h1>Search Films</h1>
    <!-- Add search form here -->
    <!-- Display search results here -->
@endsection
