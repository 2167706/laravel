@extends('layouts.app')

@section('content')
    <h1>Films starring {{ $actor->first_name }} {{ $actor->last_name }}</h1>
    
    <ul>
        @foreach ($actor->films as $film)
            <li>{{ $film->title }}</li>
            <!-- Display other film information here -->
        @endforeach
    </ul>
@endsection
