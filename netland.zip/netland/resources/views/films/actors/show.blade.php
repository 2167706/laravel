@extends('layouts.app')

@section('content')
    <h1>{{ $film->title }}</h1>
    <p><strong>Rating:</strong> {{ $film->rating }}</p>
    <p><strong>Release Date:</strong> {{ $film->released_at }}</p>
    <p><strong>Summary:</strong> {{ $film->summary }}</p>
    <!-- Display other film information here -->
@endsection
