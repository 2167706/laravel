<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Netland</title>
</head>
<body>
    <div>
        <h1>Welcome to Netland</h1>
        <h2>Featured Films</h2>
        <ul>
            @foreach ($films as $film)
                <li>{{ $film->title }}</li>
            @endforeach
        </ul>
        <h2>Featured Actors</h2>
        <ul>
            @foreach ($actors as $actor)
                <li>{{ $actor->first_name }} {{ $actor->last_name }}</li>
            @endforeach
        </ul>
    </div>
</body>
</html>
